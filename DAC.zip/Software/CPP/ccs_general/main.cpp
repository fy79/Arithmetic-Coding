//
//  main.cpp
//  dac_ccs
//
//  Created by 勇 方 on 7/29/16.
//  Copyright © 2016 Yong. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <memory.h>
#include <float.h>
#include <iostream>
using namespace std;

typedef unsigned char byte;

// binary entropy function
#define H(p)	(((p)*(1-(p))==0.0) ? (0.0) : ((-(p)*log(p)-(1-(p))*log(1-(p)))/log(2.0)))

// parameters to control the AC codec
const int ACBITS = 32;
const unsigned HRANGE = (1<<(ACBITS-1));    // half of the range
const unsigned QRANGE = (1<<(ACBITS-2));    // quarter of the range
const unsigned MASK = ((HRANGE-1)+HRANGE);

// local variables used in this file
double top0[2], bot1[2];
void set_intervals(double p, double r){
    top0[0] = (1-p);            // upper bound of 0 for tail
    top0[1] = pow(1-p, r);		// upper bound of 0 for body
    bot1[0] = (1-p);            // lower bound of 1 for tail
    bot1[1] = (1 - pow(p, r));	// lower bound of 1 for body
}

byte _bittest(const unsigned* _BitBase, int _BitPos) {return (*_BitBase>>_BitPos)&1;}

// encode one source symbol
void encode_symbol(byte *str, unsigned &low, unsigned &high, int &nuf, int &ptr, byte s, bool isb){
    if(s)	low += unsigned(ceil((high-low)*bot1[isb] + bot1[isb]));
    else	high = low + (unsigned(ceil((high-low)*top0[isb] + top0[isb])) - 1U);
    
    /* If this test passes, the MSDigits can be sent to the output stream. */
    while (1) {
        byte msbh = _bittest(&high, ACBITS-1), msbl = _bittest(&low, ACBITS-1);
        if(msbh==msbl){
            str[ptr++] = msbl;
            low <<= 1; high <<= 1; high |= 1;
            while (nuf) {
                str[ptr++] = !msbl;
                nuf--;
            }
        }else break;
    }
    low &= MASK; high &= MASK;
    
    /* If this test passes, the numbers are in danger of underflow. */
    while(!_bittest(&high, ACBITS-2) && _bittest(&low, ACBITS-2)){
        nuf++;
        low  -= QRANGE;	low  <<= 1;
        high -= QRANGE;	high <<= 1;	high |= 1;
    }
}

int compress(byte *str, byte *src, int n, int t){
    unsigned low = 0, high = MASK;
    int nuf = 0, ptr = 0;
    for(int i=0; i<n; i++){
        encode_symbol(str, low, high, nuf, ptr, src[i], (i<(n-t)));
    }
    str[ptr++] = 1;   // this bit is VERY important for the final CCS
    return ptr;
}

// remove one source symbol
void remove_symbol(byte *str, unsigned &low, unsigned &high, unsigned &code, int &ptr, byte s, bool isb){
    if(s)	low += unsigned(ceil((high-low)*bot1[isb] + bot1[isb]));
    else	high = low + (unsigned(ceil((high-low)*top0[isb] + top0[isb])) - 1U);
    
    /* If the MSDigits match, the bits will be shifted out. */
    while(_bittest(&high, ACBITS-1)==_bittest(&low, ACBITS-1)){
        low  <<= 1;
        high <<= 1;	high |= 1;
        code <<= 1; code |= str[ptr++];
    }
    low &= MASK; high &= MASK; code &= MASK;
    
    /* If underflow is threatening, shift out the 2nd MSDigit. */
    while(!_bittest(&high, ACBITS-2) && _bittest(&low, ACBITS-2)){
        low  -= QRANGE;	low  <<= 1;
        high -= QRANGE;	high <<= 1;	high |= 1;
        code -= QRANGE;	code <<= 1; code |= str[ptr++];
    }
}

unsigned expand(byte *str, byte *src, int n, int t, double **ccs, int ncells){
    unsigned low = 0, high = MASK, code = 0;
    int ptr = 0;
    for(int i=0; i<ACBITS; i++){
        code <<= 1;
        code |= str[ptr++];
    }
    for(int i=0; i<n; i++){
        double u = (code-low)/(high-low+1.0);
        ccs[i][int(u*ncells)]++;
        remove_symbol(str, low, high, code, ptr, src[i], (i<(n-t)));
    }
    double u = (code-low)/(high-low+1.0);   // final CCS
    ccs[n][int(u*ncells)]++;
    return 0;
}

void print_settings(int n, int t, double r, double p, int ncells, int ntries){
    double R = (r*(n-t)+t)*H(p)/n;  // code rate
    cout<<"************************Settings**********************\n";
    cout<<"p = "<<p<<endl<<"H(p) = "<<H(p)<<endl<<"R = "<<R<<endl;
    cout<<"n = "<<n<<endl<<"t = "<<t<<endl<<"r = "<<r<<endl;
    cout<<"Number of Cells: "<<ncells<<endl;
    cout<<"Number of Tries: "<<ntries<<endl;
    cout<<"********************End of Settings*******************\n\n";
}

// n t r p ncells ntries file_name seed
int main(int argc, const char * argv[]) {
    // load and print settingsr
    int n = atoi(argv[1]);      // code length
    int t = atoi(argv[2]);      // tail length
    double r = atof(argv[3]);   // overlap factor for body
    double p = atof(argv[4]);   // bias probability of source
    set_intervals(p, r);
    int ncells = atoi(argv[5]); // number of cells
    int ntries = atoi(argv[6]); // number of tries
    print_settings(n, t, r, p, ncells, ntries);
    FILE *fp = fopen(argv[7], "wt");    // ccs file
    if(!fp){
        cout<<"File open fails!\n";
        return 1;
    }
    int seed = atoi(argv[8]);      // initial seed
    srand(seed); // srand((unsigned)_rdtsc());
    
    // allocate memory
    double *allccs = new double[(n+1)*ncells];
    memset(allccs, 0, sizeof(double)*(n+1)*ncells);
    double **ccs = new double*[n+1];
    for(int i=0; i<=n; i++){
        ccs[i] = allccs + i*ncells;
    }
    byte *src = new byte[5*n], *str = src+n;
    
    // codec
    for(int k=0; k<ntries; k++){
        for(int i=0; i<n; i++){// generate source block
            src[i] = (rand()<RAND_MAX*p);
        }
        memset(str, 0, 4*n);    // clear bitstream
        compress(str, src, n, t);
        expand(str, src, n, t, ccs, ncells);
    }
    
    // output CCS
    for(int i=0; i<=n; i++){
        for(int j=0; j<ncells; j++){
            ccs[i][j] = (ccs[i][j]*ncells)/ntries;
            fprintf(fp, "%f\n", ccs[i][j]);
        }
    }
    fclose(fp);
    
    delete[] src;
    delete[] allccs;
    return 0;
}