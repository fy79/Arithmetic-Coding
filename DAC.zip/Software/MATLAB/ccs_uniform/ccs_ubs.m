ncells = 256;
u = (0:(ncells-1))/ncells;
p = 0.5;
t = 0;
r = 0.5;

%%
n = 128;
fp = fopen('128_0_.5_.5_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf = pdf';
plot(u, pdf(n+1,:)); hold on;

tau = ceil(n*r) - n*r;
fnu = get_psi(tau, ncells);
plot(u, fnu, '--');

%%
n = 129;
fp = fopen('129_0_.5_.5_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf  = pdf';
plot(u, pdf(n+1,:), '-.');

tau = ceil(n*r) - n*r;
fnu = get_psi(tau, ncells);
plot(u, fnu, ':');

%%
grid on;
axis tight;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_n(u)$'}, 'interpreter', 'latex');
legend({'$n=128$, empiric', '$n=128$, analytic', '$n=129$, empiric', '$n=129$, analytic'}, 'interpreter', 'latex');
title({'$t=0$, $r=0.5$, $p=0.5$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);

%%
ccs = evolution(n,t,r,p,fnu);
figure(2);
plot(u, pdf(n,:)); hold on;
plot(u, ccs(n,:), '--');
plot(u, pdf(1,:), '-.');
plot(u, ccs(1,:), ':');
grid on;
axis tight;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_i(u)$'}, 'interpreter', 'latex');
legend({'$f_{n-1}(u)$, empiric', '$f_{n-1}(u)$, analytic', '$f_0(u)$, empiric', '$f_0(u)$, analytic'}, 'interpreter', 'latex');
title({'$n=129$, $t=0$, $r=0.5$, $p=0.5$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);