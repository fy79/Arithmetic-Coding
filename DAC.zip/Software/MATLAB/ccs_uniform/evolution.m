function ccs = evolution(n,t,r,p,fnu)
ncells = length(fnu);
ccs = zeros(n+1, ncells);
ccs(n+1,:) = fnu;

for i=n:(-1):(n-t+1)
    H0 = floor((ncells-1)*(1-p));
    u0 = round((0:H0)/(1-p));
    ccs(i,(0:H0)+1) = ccs(i+1, u0+1);

    L1 = ceil(ncells*(1-p));
    u1 = round(((L1:(ncells-1))-ncells*(1-p))/p);
    ccs(i,((L1+1):ncells)) = ccs(i,((L1+1):ncells)) + ccs(i+1, u1+1); 
    ccs(i,:) = ncells * ccs(i,:)/sum(ccs(i,:));
end

for i=(n-t):(-1):1
    H0 = floor((ncells-1)*(1-p)^r);
    u0 = round((0:H0)/(1-p)^r);
    ccs(i,(0:H0)+1) = (1-p)^(1-r)*ccs(i+1, u0+1);

    L1 = ceil(ncells*(1-p^r));
    u1 = round(((L1:(ncells-1))-ncells*(1-p^r))/p^r);
    ccs(i,((L1+1):ncells)) = ccs(i,((L1+1):ncells)) + p^(1-r)*ccs(i+1, u1+1); 
    ccs(i,:) = ncells * ccs(i,:)/sum(ccs(i,:));
end


% t = 1:(floor(ncells*(1-p)^r)+1);
% newt = floor(t./(1-p)^r);
% s = (floor(ncells*(1-p^r))+1):ncells;
% news = floor((s-floor(ncells*(1-p^r)))./p^r);
% newpdf = zeros(size(allpdf));
% newpdf(t) = (1-p)^(1-r)*allpdf(newt);
% newpdf(s) = newpdf(s) + p^(1-r)*allpdf(news);
% figure(3);
% %plot((0:(ncells-1))/ncells, newpdf);
% plot(newpdf);
% hold on;


