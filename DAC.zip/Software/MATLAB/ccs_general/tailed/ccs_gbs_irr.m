ncells = 256;
u = (0:(ncells-1))/ncells;
r = 0.5;
p = 0.3;

%%
n = 256;
t = 64;
fp = fopen('256_64_.5_.3_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf = pdf';
plot(u, pdf(n+1,:), '--'); hold on;
% fnu = get_fnu_anal(n, t, r, p, ncells);
% plot(u, fnu, '--');

n = 128;
t = 32;
fp = fopen('128_32_.5_.3_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf = pdf';
plot(u, pdf(n+1,:), '-.'); hold on;


%%
fnu_asym = [1./(ncells:(-1):(ncells/2+1)), 1./((ncells/2+1):(ncells))];
fnu_asym = (1/(2*log(2))) * ncells * fnu_asym; 
plot(u, fnu_asym);

%%
grid on;
axis tight;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_n(u)$'}, 'interpreter', 'latex');
legend({'$n=256$, $t=64$, empiric', '$n=128$, $t=32$, empiric', 'analytic'}, 'interpreter', 'latex');
title({'$r=0.5$, $p=0.3$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);