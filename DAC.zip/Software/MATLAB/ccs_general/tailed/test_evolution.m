ncells = 256;
u = (0:(ncells-1))/ncells;
n = 256;
t = 64;
r = 0.5;
p = 0.3;

fp = fopen('256_64_.5_.3_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf = pdf';
fnu = get_fnu_asym(ncells);
ccs = evolution(n,t,r,p,fnu);

plot(u, pdf(n,:), '-.'); hold on;
plot(u, ccs(n,:));

plot(u, pdf(n-t+1,:), ':');
plot(u, pdf(1,:) ,'--');

%%
grid on;
axis tight;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_i(u)$'}, 'interpreter', 'latex');
legend({'$f_{n-1}(u)$, empiric', '$f_{n-1}(u)$, analytic', '$f_{n-t}(u)$, empiric', '$f_0(u)$, empiric'}, 'interpreter', 'latex');
title({'$n=256$, $t=64$, $r=0.5$, $p=0.3$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);