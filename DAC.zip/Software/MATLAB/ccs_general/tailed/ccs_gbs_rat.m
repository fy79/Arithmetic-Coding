ncells = 256;
u = (0:(ncells-1))/ncells;

%%
n = 256;
t = 64;
r = 0.5;

%%
p = 0.4425;
% empiric
fp = fopen('256_64_.5_.4425_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells,n+1]);
pdf = pdf';
plot(u, pdf(n+1,:), '--'); hold on;
% analytic
tau0 = get_tau0(n,t,r,p);
fnu = get_psi(tau0, ncells);
for k=1:5
    fnu = fnu + get_psi(tau0+k/6, ncells);
end
plot(u, fnu/6);

% %%
% ccs = evolution(n,t,r,p,fnu);
% plot(u, pdf(n,:), '-.');
% plot(u, ccs(n,:));

%%
grid on;
axis tight;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_n(u)$'}, 'interpreter', 'latex');
legend({'empiric', 'analytic'}, 'interpreter', 'latex');
title({'$n=256$, $t=64$, $r=0.5$, $p=0.4425$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);

% plot(u, pdf(n-t+1,:));
% plot(u, ccs(n-t+1,:));



%%
% n = 256;
% t = 64;  
% r = 0.5;
% p = 0.3;
% % empiric
% fp = fopen('256_64_.5_.3_256.txt', 'r');
% pdf = fscanf(fp, '%f', [ncells, n+1]);
% plot(u, pdf(:,n+1)); hold on;
% % analytic
% fnu = get_fnu_asym(ncells);
% plot(u, fnu);
% ccs = evolution(n,t,r,p,fnu);
% 

% %%
% n = 256;
% fp = fopen('256_0_.25_.2_256.txt', 'r');
% pdf = fscanf(fp, '%f', [ncells, n+1]);
% plot(u, pdf(:,n+1)); hold on;
% 
% %%
% weight = zeros(1,n+1);
% for k=0:floor(n/2)
%     temp = 1;
%     for i=0:(k-1)
%         temp = temp * ((n-i)*p*(1-p))/(k-i);
%     end 
%     weight(k+1) = temp * (1-p)^(n-2*k);
%     weight(n-k+1) = temp * p^(n-2*k);
% end
% ccs = zeros(1, ncells);
% for k=0:n
%     prob = r*k*log2(p) + r*(n-k)*log2(1-p);
%     tau = prob - floor(prob);
%     tmp = get_psi(tau, ncells);
%     ccs = ccs + weight(k+1)*tmp;   
% end
% plot(u, ccs);
% 
% %%
% grid on;
% axis tight;
% xlabel({'$u$'}, 'interpreter', 'latex');
% ylabel({'$f_n(u)$'}, 'interpreter', 'latex');
% legend({'$n=128$, empiric', '$n=128$, analytic', '$n=256$, empiric', '$n=256$, analytic'}, 'interpreter', 'latex');
% title({'$t=0$, $r=0.25$, $p=0.2$'}, 'interpreter', 'latex');
