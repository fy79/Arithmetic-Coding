function ccs = evolution(n,t,r,p,fnu)
ncells = length(fnu);
ccs = zeros(n+1, ncells);
ccs(n+1,:) = fnu;

%% tail
for i=n:(-1):(n-t+1)
    H0 = round(ncells*(1-p));
    u0 = floor((0:(H0-1))/(1-p));
    ccs(i,(1:H0)) = ccs(i+1, u0+1);

    L1 = round(ncells*(1-p));
    u1 = floor(((L1:(ncells-1))-L1)/p);
    ccs(i,((L1+1):ncells)) = ccs(i,((L1+1):ncells)) + ccs(i+1, u1+1); 
    ccs(i,:) = ncells * ccs(i,:)/sum(ccs(i,:));
end

%% body
for i=(n-t):(-1):1
    H0 = round(ncells*(1-p)^r);
    u0 = floor((0:(H0-1))/(1-p)^r);
    ccs(i,(1:H0)) = (1-p)^(1-r) * ccs(i+1, u0+1);

    L1 = round(ncells*(1-p^r));
    u1 = floor(((L1:(ncells-1))-L1)/p^r);
    ccs(i,((L1+1):ncells)) = ccs(i,((L1+1):ncells)) + p^(1-r) * ccs(i+1, u1+1); 
    ccs(i,:) = ncells * ccs(i,:)/sum(ccs(i,:));
end
