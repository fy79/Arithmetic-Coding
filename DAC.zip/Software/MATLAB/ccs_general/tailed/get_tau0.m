function tau0 = get_tau0(n,t,r,p)
tau0 = ((n-t)*r+t)*log2(1-p) - floor(((n-t)*r+t)*log2(1-p));
