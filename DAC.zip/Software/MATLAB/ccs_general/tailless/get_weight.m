function weight = get_weight(n,p)
weight = zeros(1,n+1);
for k=0:floor(n/2)
    temp = 1;
    for i=0:(k-1)
        temp = temp * ((n-i)*p*(1-p))/(k-i);
    end 
    weight(k+1) = temp * (1-p)^(n-2*k);
    weight(n-k+1) = temp * p^(n-2*k);
end