clc;
%%
ncells = 256;
u = (0:(ncells-1))/ncells;
n = 256;
t = 0;
r = 0.5;
p = 0.3;
fp = fopen('256_0_.5_.3_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf = pdf';

fnu = get_fnu_asym(ncells);
ccs = evolution(n,t,r,p,fnu);
%save('ccs_160_0_0.5.txt', 'p', 'n', 't', 'r', 'nccs', 'T', 'ccs', '-ascii');


plot(u, pdf(n,:), '-.'); hold on;
plot(u, ccs(n,:), '--');
plot(u, pdf(1,:), ':');
plot(u, ccs(1,:));

%%
grid on;
axis tight;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_i(u)$'}, 'interpreter', 'latex');
legend({'$f_{n-1}(u)$, empiric', '$f_{n-1}(u)$, analytic', '$f_0(u)$, empiric', '$f_0(u)$, analytic', 'asymptotic'}, 'interpreter', 'latex');
title({'$n=256$, $t=0$, $r=0.5$, $p=0.3$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);