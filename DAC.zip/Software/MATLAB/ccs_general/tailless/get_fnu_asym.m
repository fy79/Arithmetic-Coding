function fnu = get_fnu_asym(ncells)
fnu = (1/(2*log(2))) * ncells * [1./(ncells:(-1):(ncells/2+1)), 1./((ncells/2+1):(ncells))];
