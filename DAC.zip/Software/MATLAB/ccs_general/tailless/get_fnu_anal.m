function fnu = get_fnu_anal(n, t, r, p, ncells)
body = get_weight(n-t,p);
tail = get_weight(t,p);
fnu = zeros(1, ncells);
for a=0:(n-t)
    for b=0:t
        len = (a*r+b)*log2(p) + (((n-t)-a)*r+(t-b))*log2(1-p);
        tau = len - floor(len);    
        tmp = get_psi(tau, ncells);
        fnu = fnu + body(a+1)*tail(b+1)*tmp;
    end
end
