ncells = 256;
u = (0:(ncells-1))/ncells;
t = 0;
r = 0.5;
p = 0.3;

%%
n = 128;
fp = fopen('128_0_.5_.3_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf = pdf';
plot(u, pdf(n+1,:), '--'); hold on;
% fnu = get_fnu_anal(n, t, r, p, ncells);
% plot(u, fnu, ':');

%%
n = 256;
fp = fopen('256_0_.5_.3_256.txt', 'r');
pdf = fscanf(fp, '%f', [ncells, n+1]);
pdf = pdf';
plot(u, pdf(n+1,:), '-.'); hold on;

%%
fnu = get_fnu_asym(ncells);
plot(u, fnu);

%%
grid on;
axis tight;
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'$f_n(u)$'}, 'interpreter', 'latex');
legend({'$n=128$, empiric', '$n=256$, empiric', 'analytic'}, 'interpreter', 'latex');
% legend({'$n=128$, empiric', '$n=128$, analytic', '$n=256$, empiric', 'asymptotic'}, 'interpreter', 'latex');
title({'$t=0$, $r=0.5$, $p=0.3$'}, 'interpreter', 'latex');
set(gca,'FontSize',16);
