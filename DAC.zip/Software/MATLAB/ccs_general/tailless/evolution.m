function ccs = evolution(n,t,r,p,fnu)
ncells = length(fnu);
ccs = zeros(n+1, ncells);
ccs(n+1,:) = fnu;

%% tail
for i=n:(-1):(n-t+1)
    H0 = floor((ncells-1)*(1-p));
    u0 = round((0:H0)/(1-p));
    ccs(i,(0:H0)+1) = ccs(i+1, u0+1);

    L1 = ceil(ncells*(1-p));
    u1 = round(((L1:(ncells-1))-ncells*(1-p))/p);
    ccs(i,((L1+1):ncells)) = ccs(i,((L1+1):ncells)) + ccs(i+1, u1+1); 
    ccs(i,:) = ncells * ccs(i,:)/sum(ccs(i,:));
end

%% body
for i=(n-t):(-1):1
    H0 = floor((ncells-1)*(1-p)^r);
    u0 = round((0:H0)/(1-p)^r);
    ccs(i,(0:H0)+1) = (1-p)^(1-r)*ccs(i+1, u0+1);

    L1 = ceil(ncells*(1-p^r));
    u1 = round(((L1:(ncells-1))-ncells*(1-p^r))/p^r);
    ccs(i,((L1+1):ncells)) = ccs(i,((L1+1):ncells)) + p^(1-r)*ccs(i+1, u1+1); 
    ccs(i,:) = ncells * ccs(i,:)/sum(ccs(i,:));
end
