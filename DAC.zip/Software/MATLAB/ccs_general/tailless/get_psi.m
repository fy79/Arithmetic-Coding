function y = get_psi(tau, ncells)
% 0 <= tau < 1
% 0.5 < 2^(-tau)     <= 1 
% 0.5 > (1-2^(-tau)) >= 0 
%      0 <= ceil(ncells*(1-2^(-tau))) <= ncells/2
% ncells >= floor(ncells*2^(-tau))    >= ncells/2
L = ceil(ncells * (1-2^(-tau))) + 1;
H = floor(ncells * 2^(-tau));
y = 2^(tau-1) * ones(1, ncells);
if L<=H
    y(L:H) = 2^tau;
end