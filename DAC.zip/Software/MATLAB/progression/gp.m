clc;
clear;

n = 2^11+2^9;             % number of samples
t = 256;
m = 2^5;   % number of discretized cells.
pdf = zeros(1,m);


%% conjecture 1
r = 1 + (pi-3)*1e-1;    % common ratio
g = r.^(1:n);           % geometric progression  
f = g - floor(g) - 0.5; % shifted fractional part

% R = acf(f,t);
% plot(-t:t, R, '-+'); hold on; 

pdf(:) = 0;
index = floor((f+0.5)*m)+1;
for i=1:n
    pdf(index(i)) = pdf(index(i)) + 1;
end
stem((0:1/m:(1-1/m)), m*pdf/n); hold on;


%% conjecture 3
r = 1.014;  % common ratio
g = r.^(1:n);           % geometric progression   
f = g - floor(g) - 0.5; % shifted fractional part

% R = acf(f,t);
% plot(-t:t, R, '-x');

pdf(:) = 0;
index = floor((f+0.5)*m)+1;
for i=1:n
    pdf(index(i)) = pdf(index(i)) + 1;
end
stem((0:1/m:(1-1/m)), m*pdf/n); hold on;


% %% conjecture 2
r = 2^(2^(-6)); % common ratio
g = r.^(1:n);   % geometric progression
% % I = [];
% % for i=1:2^5
% %     I = [I, ((i-1)*2^6+1):(i*2^6-1)];
% % end 
% % g = g(I);   % pick out integer samples
f = g - floor(g) - 0.5; % shifted fractional part
% R = acf(f,t);
% plot(-t:t, R, '-*'); hold on;
% x = -t:2^6:t;
% y = 1./(12*2.^(abs(x)/2^6));
% plot(x,y,'-o');

pdf(:) = 0;
index = floor((f+0.5)*m)+1;
for i=1:n
    pdf(index(i)) = pdf(index(i)) + 1;
end
stem((0:1/m:(1-1/m)), m*pdf/n); hold on;



%%
% grid on;
% axis tight;
% % title({'$n=2^{11}$, $r=2^{2^{-6}}$'}, 'interpreter', 'latex');
% title({'$n=2^{11}$'}, 'interpreter', 'latex');
% legend({'$r=1+0.1\times\{\pi\}$', '$r=1.014$'}, 'interpreter', 'latex');
% % legend({'Observed', 'Selected predictions'}, 'interpreter', 'latex');
% ylabel({'$f_{ac}(s)-0.25$'}, 'interpreter', 'latex');
% xlabel({'$s$'}, 'interpreter', 'latex');
% set(gca, 'FontSize', 16);