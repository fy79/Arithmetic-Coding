clc;
clear;

n = 2^20;
t = 8;

m = 2^6;   % number of discretized cells.
pdf = zeros(1,m);

% CD = {pi}
d = pi - floor(pi);
x = (1:n)*d - floor((1:n)*d) - 0.5;

% R = acf(x,t);
% plot(-t:t, R, '-+'); hold on; 
% y = d*abs(-t:t) - floor(d*abs(-t:t));
% z = 1/12 + y.*(y-1)/2;
% plot(-t:t,z, '-s');%, 'MarkerSize',8);

pdf(:) = 0;
index = floor((x+0.5)*m)+1;
for i=1:n
    pdf(index(i)) = pdf(index(i)) + 1;
end
stem((0:1/m:(1-1/m)), m*pdf/n); hold on;

% {e}
d = exp(1) - floor(exp(1));
x = (1:n)*d - floor((1:n)*d) - 0.5;

% R = acf(x,t);
% plot(-t:t, R, '-x'); 
% y = d*abs(-t:t) - floor(d*abs(-t:t));
% z = 1/12 + y.*(y-1)/2;
% plot(-t:t,z, '-d');%, 'MarkerSize',8);

pdf(:) = 0;
index = floor((x+0.5)*m)+1;
for i=1:n
    pdf(index(i)) = pdf(index(i)) + 1;
end
stem((0:1/m:(1-1/m)), m*pdf/n);


% {2^1/2}
d = sqrt(2) - floor(sqrt(2));
x = (1:n)*d - floor((1:n)*d) - 0.5;

% R = acf(x,t);
% plot(-t:t, R, '-*');
% y = d*abs(-t:t) - floor(d*abs(-t:t));
% z = 1/12 + y.*(y-1)/2;
% plot(-t:t,z, '-o');%, 'MarkerSize',8);

pdf(:) = 0;
index = floor((x+0.5)*m)+1;
for i=1:n
    pdf(index(i)) = pdf(index(i)) + 1;
end
stem((0:1/m:(1-1/m)), m*pdf/n);


% %grid on; 
% axis tight;
% xlabel({'Discretized Sample Value'}, 'interpreter', 'latex');
% ylabel({'Occurrence Rate'}, 'interpreter', 'latex');



% grid on;
% axis tight;
% title({'$n=2^{20}$'}, 'interpreter', 'latex');
% legend({'$\{\pi\}$, observed', '$\{\pi\}$, predicted', '$\{e\}$, observed', '$\{e\}$, predicted', '$\{\sqrt{2}\}$, observed', '$\{\sqrt{2}\}$, predicted'}, 'interpreter', 'latex');
% ylabel({'$f_{ac}(s)$-0.25'}, 'interpreter', 'latex');
% xlabel({'$s$'}, 'interpreter', 'latex');
% set(gca, 'FontSize', 16);