function R = acf(f,t)
n = length(f);
R(t+1) = sum(f.*f)/n;
for i=1:t
    R(t+1+i) = sum(f(1:(n-i)).*f((1+i):n))/(n-i);
    R(t+1-i) = R(t+1+i);
end